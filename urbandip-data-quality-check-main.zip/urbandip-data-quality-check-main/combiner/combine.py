"""Combine Observator and ColiMinder cleaned CSV files, then build aligned outputs.

Usage:
    python combine.py --input data_in --output data_out

Inputs (in the input folder):
    cleaned_data_Observator_<from>_to_<to>.csv
    cleaned_data_ColiMinder_<from>_to_<to>.csv
    The tool processes a date range only when both files exist.

Outputs (written to the output folder):
    cleaned_and_combined_data_<from>_to_<to>.csv             # per-period combined
    cleaned_and_combined_data_general.csv                    # cumulative combined
    cleaned_and_combined_and_aligned_data_<from>_to_<to>.csv # per-period aligned
    cleaned_and_combined_and_aligned_data_general.csv        # cumulative aligned
"""

from __future__ import annotations

import argparse
import re
from pathlib import Path
from typing import Dict, List, Tuple

import pandas as pd

# Desired column order taken from the example combined file (period + general).
COLUMN_ORDER: List[str] = [
    "TimeStamp",
    "Origin",
    "Activity - Coliminder",
    "BGA PC RFU",
    "BGA PC ug/L",
    "Chlorophyll RFU",
    "Chlorophyll ug/L",
    "Cond uS/cm",
    "fDOM QSU",
    "fDOM RFU",
    "microFlu_TRP",
    "pH",
    "Signal strength",
    "SpCond uS/cm",
    "Temp C",
    "Turbidity",
]

# Unit row copied from the provided sample.
UNIT_ROW = {
    "TimeStamp": "dd-mm-yyyy hh:mm:ss",
    "Origin": "",
    "Activity - Coliminder": "mMFU/100ml",
    "BGA PC RFU": "RFU",
    "BGA PC ug/L": "ug/L",
    "Chlorophyll RFU": "RFU",
    "Chlorophyll ug/L": "ug/L",
    "Cond uS/cm": "uS/cm",
    "fDOM QSU": "QSU",
    "fDOM RFU": "RFU",
    "microFlu_TRP": "g/L",
    "pH": "pH",
    "Signal strength": "dBm",
    "SpCond uS/cm": "uS/cm",
    "Temp C": "C",
    "Turbidity": "NTU",
}

OBS_PATTERN = re.compile(r"cleaned_data_Observator_(\d{8})_to_(\d{8})\.csv$")
COLI_PATTERN = re.compile(r"cleaned_data_ColiMinder_(\d{8})_to_(\d{8})\.csv$")

ORIGIN_OBS = "Observator"
ORIGIN_COLI = "Coliminder"

OBS_COLUMNS = [
    "TimeStamp",
    "BGA PC RFU",
    "BGA PC ug/L",
    "Chlorophyll RFU",
    "Chlorophyll ug/L",
    "Cond uS/cm",
    "fDOM QSU",
    "fDOM RFU",
    "microFlu_TRP",
    "pH",
    "Signal strength",
    "SpCond uS/cm",
    "Temp C",
    "Turbidity",
]

OBS_TIMESTAMP_COL = "Observator TimeStamp"
COLI_TIMESTAMP_COL = "Coliminder TimeStamp"
MEASUREMENT_COLUMNS = [c for c in COLUMN_ORDER if c not in {"TimeStamp", "Origin"}]
ALIGNED_COLUMN_ORDER = [OBS_TIMESTAMP_COL, COLI_TIMESTAMP_COL] + MEASUREMENT_COLUMNS

ALIGNED_UNIT_ROW = {
    OBS_TIMESTAMP_COL: UNIT_ROW["TimeStamp"],
    COLI_TIMESTAMP_COL: UNIT_ROW["TimeStamp"],
}
for col in MEASUREMENT_COLUMNS:
    ALIGNED_UNIT_ROW[col] = UNIT_ROW.get(col, "")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Combine Observator and ColiMinder cleaned CSV files.")
    parser.add_argument("--input", "-i", default="data_in", help="Input directory containing cleaned_data_*.csv files")
    parser.add_argument("--output", "-o", default="data_out", help="Output directory for combined CSV files")
    return parser.parse_args()


def find_pairs(input_dir: Path) -> List[Tuple[Tuple[str, str], Path, Path]]:
    """Return list of ((start, end), obs_path, coli_path) for matching date ranges."""
    obs_files: Dict[Tuple[str, str], Path] = {}
    for path in input_dir.glob("cleaned_data_Observator_*_to_*.csv"):
        match = OBS_PATTERN.match(path.name)
        if match:
            obs_files[(match.group(1), match.group(2))] = path

    coli_files: Dict[Tuple[str, str], Path] = {}
    for path in input_dir.glob("cleaned_data_ColiMinder_*_to_*.csv"):
        match = COLI_PATTERN.match(path.name)
        if match:
            coli_files[(match.group(1), match.group(2))] = path

    shared_keys = sorted(set(obs_files.keys()) & set(coli_files.keys()))
    return [(key, obs_files[key], coli_files[key]) for key in shared_keys]


def _clean_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Strip whitespace from column names for consistent matching."""
    df.columns = [c.strip() if isinstance(c, str) else c for c in df.columns]
    return df


def load_observator(path: Path) -> pd.DataFrame:
    # Skip two QC summary rows and the unit row so only measurements remain.
    df = pd.read_csv(path, skiprows=[1, 2, 3])
    df = _clean_columns(df)
    if "TimeStamp" not in df.columns:
        raise ValueError(f"Expected 'TimeStamp' column in {path.name}")
    df = df.dropna(subset=["TimeStamp"])
    # Keep only the measurement columns we need; drop QC/maintenance flags.
    cleaned = pd.DataFrame({col: df[col] if col in df.columns else pd.NA for col in OBS_COLUMNS})
    cleaned["Origin"] = ORIGIN_OBS
    cleaned["Activity - Coliminder"] = pd.NA
    # Reorder to match the final column order.
    cleaned = cleaned[COLUMN_ORDER]
    return cleaned


def load_coliminder(path: Path) -> pd.DataFrame:
    # Skip QC summary rows; keep only real measurements.
    df = pd.read_csv(path, skiprows=[1, 2])
    df = _clean_columns(df).rename(columns={"Time (UTC)": "TimeStamp", "Activity": "Activity - Coliminder"})
    if "TimeStamp" not in df.columns:
        raise ValueError(f"Expected 'Time (UTC)' column in {path.name}")
    df = df.dropna(subset=["TimeStamp", "Activity - Coliminder"], how="all")

    data = pd.DataFrame()
    data["TimeStamp"] = df["TimeStamp"]
    data["Origin"] = ORIGIN_COLI
    data["Activity - Coliminder"] = df.get("Activity - Coliminder")
    # Add empty columns for Observator-only measurements.
    for col in COLUMN_ORDER:
        if col not in data.columns:
            data[col] = pd.NA
    data = data[COLUMN_ORDER]
    return data


def sort_by_timestamp_column(df: pd.DataFrame, column: str) -> pd.DataFrame:
    ts = pd.to_datetime(df[column], dayfirst=True, errors="coerce")
    return df.assign(_ts=ts).sort_values("_ts").drop(columns="_ts")


def sort_by_timestamp(df: pd.DataFrame) -> pd.DataFrame:
    return sort_by_timestamp_column(df, "TimeStamp")


def add_unit_row(data_rows: pd.DataFrame, unit_row: Dict[str, str] | None = None) -> pd.DataFrame:
    row = unit_row or UNIT_ROW
    unit_df = pd.DataFrame([row])
    return pd.concat([unit_df, data_rows], ignore_index=True)


def write_period_file(output_dir: Path, key: Tuple[str, str], data_rows: pd.DataFrame) -> Path:
    start, end = key
    filename = f"cleaned_and_combined_data_{start}_to_{end}.csv"
    output_path = output_dir / filename
    with_unit = add_unit_row(data_rows, UNIT_ROW)
    with_unit.to_csv(output_path, index=False)
    print(f"Wrote {output_path}")
    return output_path


def update_general_file(output_dir: Path, new_rows: pd.DataFrame) -> None:
    general_path = output_dir / "cleaned_and_combined_data_general.csv"
    if general_path.exists():
        existing = pd.read_csv(general_path)
        existing_data = existing.iloc[1:] if len(existing) else pd.DataFrame(columns=COLUMN_ORDER)
    else:
        existing_data = pd.DataFrame(columns=COLUMN_ORDER)

    if existing_data.empty:
        combined = new_rows.copy()
    else:
        combined = pd.concat([existing_data.astype(object), new_rows.astype(object)], ignore_index=True)
    combined = combined[COLUMN_ORDER]
    combined = combined.drop_duplicates(subset=["TimeStamp", "Origin"], keep="first")
    combined = sort_by_timestamp(combined)

    final_df = add_unit_row(combined, UNIT_ROW)
    final_df.to_csv(general_path, index=False)
    print(f"Updated general file at {general_path}")


def combine_pair(obs_path: Path, coli_path: Path) -> pd.DataFrame:
    obs_df = load_observator(obs_path)
    coli_df = load_coliminder(coli_path)
    frames = [df.astype(object) for df in (obs_df, coli_df) if not df.empty]
    merged = pd.concat(frames, ignore_index=True) if frames else pd.DataFrame(columns=COLUMN_ORDER)
    merged = merged[COLUMN_ORDER]
    merged = sort_by_timestamp(merged)
    return merged


def align_combined_rows(combined_rows: pd.DataFrame) -> Tuple[pd.DataFrame, Dict[str, float]]:
    if combined_rows.empty:
        stats = {
            "total_coliminder_rows": 0,
            "matched_coliminder_rows": 0,
            "unmatched_coliminder_rows": 0,
            "unmatched_percentage": 0.0,
        }
        return pd.DataFrame(columns=ALIGNED_COLUMN_ORDER), stats

    obs = combined_rows.loc[combined_rows["Origin"] == ORIGIN_OBS].copy()
    coli = combined_rows.loc[combined_rows["Origin"] == ORIGIN_COLI].copy()

    obs["obs_ts"] = pd.to_datetime(obs["TimeStamp"], dayfirst=True, errors="coerce")
    coli["coli_ts"] = pd.to_datetime(coli["TimeStamp"], dayfirst=True, errors="coerce")

    obs = obs.dropna(subset=["obs_ts"]).reset_index(drop=True)
    coli = coli.dropna(subset=["coli_ts"]).reset_index(drop=True)

    assignments: Dict[int, pd.Series] = {}
    assigned_mask = pd.Series(False, index=obs.index)

    for _, coli_row in coli.iterrows():
        available = assigned_mask[~assigned_mask].index
        if len(available) == 0:
            break
        diffs = (obs.loc[available, "obs_ts"] - coli_row["coli_ts"]).abs()
        if diffs.empty:
            break
        target_idx = diffs.idxmin()
        assignments[target_idx] = coli_row
        assigned_mask.loc[target_idx] = True

    total_coli = len(coli)
    matched = len(assignments)
    unmatched = total_coli - matched
    unmatched_pct = (unmatched / total_coli * 100) if total_coli else 0.0

    aligned = pd.DataFrame(columns=ALIGNED_COLUMN_ORDER)
    aligned[OBS_TIMESTAMP_COL] = obs["TimeStamp"]
    aligned[COLI_TIMESTAMP_COL] = pd.NA
    for col in MEASUREMENT_COLUMNS:
        aligned[col] = obs[col] if col in obs.columns else pd.NA
    aligned = aligned.astype(object)

    for target_idx, coli_row in assignments.items():
        aligned.at[target_idx, COLI_TIMESTAMP_COL] = coli_row["TimeStamp"]
        for col in MEASUREMENT_COLUMNS:
            if col in coli_row and pd.notna(coli_row[col]):
                aligned.at[target_idx, col] = coli_row[col]

    aligned = sort_by_timestamp_column(aligned, OBS_TIMESTAMP_COL)

    stats = {
        "total_coliminder_rows": total_coli,
        "matched_coliminder_rows": matched,
        "unmatched_coliminder_rows": unmatched,
        "unmatched_percentage": unmatched_pct,
    }
    return aligned, stats


def write_aligned_period_file(output_dir: Path, key: Tuple[str, str], aligned_rows: pd.DataFrame) -> Path:
    start, end = key
    filename = f"cleaned_and_combined_and_aligned_data_{start}_to_{end}.csv"
    output_path = output_dir / filename
    with_unit = add_unit_row(aligned_rows, ALIGNED_UNIT_ROW)
    with_unit.to_csv(output_path, index=False)
    print(f"Wrote aligned {output_path}")
    return output_path


def update_aligned_general_file(output_dir: Path, new_rows: pd.DataFrame) -> None:
    general_path = output_dir / "cleaned_and_combined_and_aligned_data_general.csv"
    if general_path.exists():
        existing = pd.read_csv(general_path)
        existing_data = existing.iloc[1:] if len(existing) else pd.DataFrame(columns=ALIGNED_COLUMN_ORDER)
    else:
        existing_data = pd.DataFrame(columns=ALIGNED_COLUMN_ORDER)

    if existing_data.empty:
        combined = new_rows.copy()
    else:
        combined = pd.concat([existing_data.astype(object), new_rows.astype(object)], ignore_index=True)

    combined = combined[ALIGNED_COLUMN_ORDER]
    combined = combined.drop_duplicates(subset=[OBS_TIMESTAMP_COL], keep="first")
    combined = sort_by_timestamp_column(combined, OBS_TIMESTAMP_COL)

    final_df = add_unit_row(combined, ALIGNED_UNIT_ROW)
    final_df.to_csv(general_path, index=False)
    print(f"Updated aligned general file at {general_path}")


def print_alignment_summary(stats: Dict[str, float]) -> None:
    print(f"Total ColiMinder rows: {stats['total_coliminder_rows']}")
    print(f"Matched ColiMinder rows: {stats['matched_coliminder_rows']}")
    print(f"Unmatched ColiMinder rows: {stats['unmatched_coliminder_rows']}")
    print(f"Unmatched percentage: {stats['unmatched_percentage']:.2f}%")


def main() -> None:
    args = parse_args()
    input_dir = Path(args.input)
    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)

    pairs = find_pairs(input_dir)
    if not pairs:
        print("No matching Observator/ColiMinder file pairs found. Nothing to do.")
        return

    for key, obs_path, coli_path in pairs:
        print(f"Processing date range {key[0]} to {key[1]}")
        combined_rows = combine_pair(obs_path, coli_path)
        write_period_file(output_dir, key, combined_rows)
        update_general_file(output_dir, combined_rows)

        aligned_rows, stats = align_combined_rows(combined_rows)
        write_aligned_period_file(output_dir, key, aligned_rows)
        update_aligned_general_file(output_dir, aligned_rows)
        print_alignment_summary(stats)


if __name__ == "__main__":
    main()
